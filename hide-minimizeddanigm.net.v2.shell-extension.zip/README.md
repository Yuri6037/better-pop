# GNOME shell hide minimized in overview

This is a gnome shell extension to hide minimized windows in overview

## How to install:

You can install this extension from https://extensions.gnome.org

Or you can do it by hand, downloading this repository to your local shell extensions folder `~/.local/share/gnome-shell/extensions`.
